#!/usr/bin/env bash
set -euo pipefail

# TopTier 2026 — Check Suite (2x)
#
# Runs ALL bundled checks and scans twice back-to-back, without modifying files.
# Use this AFTER applying the kit to prove everything is stable/deterministic.
#
# Usage:
#   bash scripts/run_checks_twice.sh
#   bash scripts/run_checks_twice.sh --all-pages
#   bash scripts/run_checks_twice.sh --root ./public
#   bash scripts/run_checks_twice.sh --root ./public --all-pages

ROOT="."
ALL_FLAG=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --root)
      ROOT="${2:-.}"
      shift 2
      ;;
    --all-pages)
      ALL_FLAG="--all"
      shift 1
      ;;
    *)
      echo "Unknown arg: $1" >&2
      shift 1
      ;;
  esac

done

cd "$ROOT"

run_once() {
  local pass="$1"
  echo
  echo "==== CHECK PASS ${pass} ===="

  # Legacy license must be absent (git-aware when possible)
  bash scripts/verify_no_old_license.sh

  # Must return 0 if nothing needs changing
  python3 scripts/license_sweep.py --root .

  # Must return 0 if already wired
  if [[ -n "$ALL_FLAG" ]]; then
    python3 scripts/tt2026_wire_up.py --root . $ALL_FLAG
  else
    python3 scripts/tt2026_wire_up.py --root .
  fi

  # Must return 0 if no swaps pending (or paths differ)
  python3 scripts/tt2026_image_swaps.py --root .

  echo "✅ CHECK PASS ${pass} OK"
}

run_once 1
run_once 2

echo
echo "✅ SUCCESS: two consecutive error-free check passes."
