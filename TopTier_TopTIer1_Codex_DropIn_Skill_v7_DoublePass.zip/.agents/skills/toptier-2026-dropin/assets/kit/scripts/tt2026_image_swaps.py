#!/usr/bin/env python3
"""TopTier 2026 — Targeted Image Swap Sweeper

Replaces specific legacy <img src="..."> tags with new <picture> responsive blocks.

This script is intentionally conservative:
  - Only swaps known legacy src paths listed in SWAPS.
  - Leaves anything else untouched.

Usage:
  python3 scripts/tt2026_image_swaps.py --root .           # dry-run
  python3 scripts/tt2026_image_swaps.py --root . --apply   # apply

Notes:
  - It does NOT delete old images.
  - You can safely run multiple times (idempotent after first swap).
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

EXCLUDE_DIRS = {'.git', 'node_modules', 'dist', 'build', '.next', '.cache', '.vercel', '.netlify'}

@dataclass
class Hit:
    path: Path
    swaps: List[str]


def iter_html_files(root: Path) -> Iterable[Path]:
    for p in root.rglob('*.html'):
        if any(part in EXCLUDE_DIRS for part in p.parts):
            continue
        yield p


# Legacy src -> picture snippet
SWAPS: Dict[str, str] = {
    '/assets/images/hero.jpg': """<picture>
  <source type="image/avif" srcset="/assets/images/optimized/hero-640.avif 640w, /assets/images/optimized/hero-1280.avif 1280w, /assets/images/optimized/hero-1600.avif 1600w" sizes="(max-width: 980px) 100vw, 42vw">
  <source type="image/webp" srcset="/assets/images/optimized/hero-640.webp 640w, /assets/images/optimized/hero-1280.webp 1280w, /assets/images/optimized/hero-1600.webp 1600w" sizes="(max-width: 980px) 100vw, 42vw">
  <img src="/assets/images/optimized/hero-1280.jpg" width="1280" height="960" alt="Top Tier Electrical services at work in West Michigan" loading="eager" fetchpriority="high" decoding="async">
</picture>""",
    '/assets/images/projects/panel-work.jpg': """<picture>
  <source type="image/avif" srcset="/assets/images/optimized/panel-work-640.avif 640w, /assets/images/optimized/panel-work-1280.avif 1280w, /assets/images/optimized/panel-work-1920.avif 1920w" sizes="(max-width: 980px) 100vw, 50vw">
  <source type="image/webp" srcset="/assets/images/optimized/panel-work-640.webp 640w, /assets/images/optimized/panel-work-1280.webp 1280w, /assets/images/optimized/panel-work-1920.webp 1920w" sizes="(max-width: 980px) 100vw, 50vw">
  <img src="/assets/images/optimized/panel-work-1280.jpg" width="1280" height="960" alt="Electrical panel installation" loading="lazy" decoding="async">
</picture>""",
    '/assets/images/projects/control-work.jpg': """<picture>
  <source type="image/webp" srcset="/assets/images/optimized/control-work-640.webp 640w, /assets/images/optimized/control-work-1280.webp 1280w" sizes="(max-width: 980px) 100vw, 50vw">
  <img src="/assets/images/optimized/control-work-1280.jpg" width="1280" height="960" alt="Control wiring and electrical work" loading="lazy" decoding="async">
</picture>""",
    '/assets/images/projects/kitchen-led.jpg': """<picture>
  <source type="image/webp" srcset="/assets/images/optimized/kitchen-led-640.webp 640w, /assets/images/optimized/kitchen-led-1280.webp 1280w" sizes="(max-width: 980px) 100vw, 50vw">
  <img src="/assets/images/optimized/kitchen-led-1280.jpg" width="1280" height="960" alt="Kitchen LED lighting upgrade" loading="lazy" decoding="async">
</picture>""",
    '/assets/images/projects/480v-3-phase.jpg': """<picture>
  <source type="image/webp" srcset="/assets/images/optimized/480v-3-phase-640.webp 640w, /assets/images/optimized/480v-3-phase-1280.webp 1280w" sizes="(max-width: 980px) 100vw, 50vw">
  <img src="/assets/images/optimized/480v-3-phase-1280.jpg" width="1280" height="960" alt="Commercial 480V 3-phase electrical work" loading="lazy" decoding="async">
</picture>""",
    '/assets/images/projects/transformer.jpg': """<picture>
  <source type="image/webp" srcset="/assets/images/optimized/transformer-640.webp 640w, /assets/images/optimized/transformer-1280.webp 1280w" sizes="(max-width: 980px) 100vw, 50vw">
  <img src="/assets/images/optimized/transformer-1280.jpg" width="1280" height="960" alt="Transformer and commercial electrical equipment" loading="lazy" decoding="async">
</picture>""",
    '/assets/images/projects/service-upgrade-before.jpg': """<picture>
  <source type="image/webp" srcset="/assets/images/optimized/service-upgrade-before-640.webp 640w, /assets/images/optimized/service-upgrade-before-1280.webp 1280w" sizes="(max-width: 980px) 100vw, 50vw">
  <img src="/assets/images/optimized/service-upgrade-before-1280.jpg" width="1280" height="960" alt="Service upgrade before photo" loading="lazy" decoding="async">
</picture>""",
    '/assets/images/projects/conduit.jpg': """<picture>
  <source type="image/webp" srcset="/assets/images/optimized/conduit-640.webp 640w, /assets/images/optimized/conduit-1280.webp 1280w" sizes="(max-width: 980px) 100vw, 50vw">
  <img src="/assets/images/optimized/conduit-1280.jpg" width="1280" height="960" alt="Conduit installation" loading="lazy" decoding="async">
</picture>""",
    # EV placeholder swap
    '/assets/images/projects/myenergi-ev-charger.jpg': """<picture>
  <source type="image/avif" srcset="/assets/images/optimized/ev-unsplash-640.avif 640w, /assets/images/optimized/ev-unsplash-1280.avif 1280w, /assets/images/optimized/ev-unsplash-1920.avif 1920w" sizes="(max-width: 980px) 100vw, 50vw">
  <source type="image/webp" srcset="/assets/images/optimized/ev-unsplash-640.webp 640w, /assets/images/optimized/ev-unsplash-1280.webp 1280w, /assets/images/optimized/ev-unsplash-1920.webp 1920w" sizes="(max-width: 980px) 100vw, 50vw">
  <img src="/assets/images/optimized/ev-unsplash-1280.jpg" width="1280" height="853" alt="EV charger installation" loading="lazy" decoding="async">
</picture>""",
}


def swap_images(html: str) -> Tuple[str, List[str]]:
    swaps_done: List[str] = []
    updated = html

    for legacy_src, picture_snip in SWAPS.items():
        # If picture snippet already present, skip.
        if picture_snip.splitlines()[0] in updated and legacy_src not in updated:
            continue

        # Replace any <img ... src="legacy_src" ...> with picture snippet
        pattern = re.compile(r'<img\b[^>]*\bsrc=["\']' + re.escape(legacy_src) + r'["\'][^>]*>', flags=re.IGNORECASE)
        if pattern.search(updated):
            updated = pattern.sub(picture_snip, updated)
            swaps_done.append(legacy_src)

    return updated, swaps_done


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.', help='Project root')
    ap.add_argument('--apply', action='store_true', help='Write changes (default: dry-run)')
    args = ap.parse_args()

    root = Path(args.root).resolve()
    hits: List[Hit] = []

    for f in iter_html_files(root):
        try:
            text = f.read_text(encoding='utf-8')
        except Exception:
            continue
        updated, swaps = swap_images(text)
        if swaps:
            hits.append(Hit(f, swaps))
            if args.apply:
                f.write_text(updated, encoding='utf-8')

    print('\n=== TopTier 2026 Image Swap Report ===')
    print(f'Root: {root}')
    print(f'Mode: {"APPLY" if args.apply else "DRY-RUN"}\n')

    if not hits:
        print('No matching legacy image src found. (This can be OK if paths differ.)')
        return 0

    for h in hits:
        rel = h.path.relative_to(root)
        print(f'- {rel}: swapped ' + ', '.join(h.swaps))

    return 0 if args.apply else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(2)
