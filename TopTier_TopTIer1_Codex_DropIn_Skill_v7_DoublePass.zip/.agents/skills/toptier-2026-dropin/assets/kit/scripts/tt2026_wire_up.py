#!/usr/bin/env python3
"""TopTier 2026 — HTML Wire-Up Sweeper

Adds the 2026 drop-in CSS/JS and baseline meta tags to selected HTML pages.

Default scope (safe rollout):
  - index.html
  - services.html
  - booking.html
  - contact.html

It can also run on all HTML files with --all.

What it adds (idempotent):
  - <link rel="stylesheet" href="/css/tt2026.css?v=2026-01">
  - <script src="/js/tt2026.js?v=2026-01" defer></script>
  - OG default image tags (if og:image not already set)
  - Adds `tt2026` to <body class="...">

It will NOT insert GTM automatically.

Usage:
  python3 scripts/tt2026_wire_up.py --root .              # dry-run
  python3 scripts/tt2026_wire_up.py --root . --apply      # apply to default scope
  python3 scripts/tt2026_wire_up.py --root . --all --apply

Exit codes:
  0 success
  1 changes needed (dry-run found diffs)
  2 unexpected error
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Tuple

CSS_HREF = '/css/tt2026.css?v=2026-01'
JS_SRC = '/js/tt2026.js?v=2026-01'
OG_IMAGE = 'https://toptier-electrical.com/assets/og/og-default.jpg'

DEFAULT_FILES = {'index.html', 'services.html', 'booking.html', 'contact.html'}

EXCLUDE_DIRS = {'.git', 'node_modules', 'dist', 'build', '.next', '.cache', '.vercel', '.netlify'}

@dataclass
class Report:
    path: Path
    changed: bool
    notes: List[str]


def iter_html_files(root: Path) -> Iterable[Path]:
    for p in root.rglob('*.html'):
        if any(part in EXCLUDE_DIRS for part in p.parts):
            continue
        yield p


def add_body_class(html: str, class_name: str = 'tt2026') -> Tuple[str, bool]:
    # Match <body ...>
    m = re.search(r'<body\b([^>]*)>', html, flags=re.IGNORECASE)
    if not m:
        return html, False

    body_tag = m.group(0)
    attrs = m.group(1)

    # If class already includes tt2026, done
    class_match = re.search(r'\bclass\s*=\s*(["\'])(.*?)\1', attrs, flags=re.IGNORECASE|re.DOTALL)
    if class_match:
        quote = class_match.group(1)
        classes = class_match.group(2)
        if re.search(r'\b' + re.escape(class_name) + r'\b', classes):
            return html, False
        new_classes = (classes + ' ' + class_name).strip()
        new_attrs = attrs[:class_match.start()] + f'class={quote}{new_classes}{quote}' + attrs[class_match.end():]
        new_body = f'<body{new_attrs}>'
    else:
        new_body = f'<body class="{class_name}"{attrs}>'

    new_html = html[:m.start()] + new_body + html[m.end():]
    return new_html, True


def ensure_in_head(html: str, snippet: str, must_contain: str) -> Tuple[str, bool]:
    if must_contain in html:
        return html, False
    head_close = re.search(r'</head\s*>', html, flags=re.IGNORECASE)
    if not head_close:
        return html, False
    insert_at = head_close.start()
    return html[:insert_at] + snippet + '\n' + html[insert_at:], True


def ensure_og_image(html: str) -> Tuple[str, bool]:
    # If any og:image exists, don't add default.
    if re.search(r'property\s*=\s*["\']og:image["\']', html, flags=re.IGNORECASE):
        return html, False

    snippet = (
        f'<meta property="og:image" content="{OG_IMAGE}">' + '\n'
        f'<meta property="og:image:width" content="1200">' + '\n'
        f'<meta property="og:image:height" content="630">'
    )
    return ensure_in_head(html, snippet, 'og:image" content="')


def process(html: str) -> Tuple[str, List[str], bool]:
    notes: List[str] = []
    changed_any = False

    # Body class
    html2, ch = add_body_class(html, 'tt2026')
    if ch:
        notes.append('added body.tt2026')
        changed_any = True
    html = html2

    # CSS
    css_snip = f'<link rel="stylesheet" href="{CSS_HREF}">'
    html2, ch = ensure_in_head(html, css_snip, 'tt2026.css')
    if ch:
        notes.append('added tt2026.css')
        changed_any = True
    html = html2

    # OG default
    html2, ch = ensure_og_image(html)
    if ch:
        notes.append('added default og:image')
        changed_any = True
    html = html2

    # JS
    js_snip = f'<script src="{JS_SRC}" defer></script>'
    html2, ch = ensure_in_head(html, js_snip, 'tt2026.js')
    if ch:
        notes.append('added tt2026.js')
        changed_any = True
    html = html2

    return html, notes, changed_any


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.', help='Project root (default: .)')
    ap.add_argument('--apply', action='store_true', help='Write changes (default: dry-run)')
    ap.add_argument('--all', action='store_true', help='Process all HTML files (default: only core pages)')
    args = ap.parse_args()

    root = Path(args.root).resolve()
    reports: List[Report] = []

    for f in iter_html_files(root):
        if not args.all and f.name not in DEFAULT_FILES:
            continue
        try:
            text = f.read_text(encoding='utf-8')
        except Exception:
            continue

        updated, notes, changed = process(text)
        if changed and args.apply:
            f.write_text(updated, encoding='utf-8')

        if changed:
            reports.append(Report(f, True, notes))

    print('\n=== TopTier 2026 Wire-Up Report ===')
    print(f'Root: {root}')
    print(f'Mode: {"APPLY" if args.apply else "DRY-RUN"}')
    print(f'Scope: {"ALL HTML" if args.all else "CORE PAGES ONLY"}\n')

    if reports:
        for r in reports:
            rel = r.path.relative_to(root)
            print(f'- {rel}: ' + ', '.join(r.notes))
        return 0 if args.apply else 1

    print('No changes needed (already wired).')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(2)
