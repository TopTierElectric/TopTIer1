#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"

echo "== TopTier License Update Runner =="
echo "Root: ${ROOT}"
echo
echo "1) Dry-run scan (no changes)"
python3 scripts/license_sweep.py --root "${ROOT}"
echo
echo "2) Apply changes"
python3 scripts/license_sweep.py --root "${ROOT}" --apply
echo
echo "3) Verify legacy license removed"
bash scripts/verify_no_old_license.sh
echo "OK: legacy license number not found."
