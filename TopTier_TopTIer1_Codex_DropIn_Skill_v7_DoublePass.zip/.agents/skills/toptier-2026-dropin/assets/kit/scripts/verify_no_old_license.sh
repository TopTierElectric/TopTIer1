#!/usr/bin/env bash
set -euo pipefail

# Compute the legacy license number without embedding it as plain text.
OLD="$(printf '\x36\x33\x31\x32\x31\x30')"

# Prefer git-aware search (avoids untracked backups / build artifacts).
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if git grep -nF "${OLD}" -- . ; then
    echo
    echo "❌ Found forbidden legacy license number (tracked files)."
    echo "   Replace with: MI Master Electrician License #6220430"
    exit 1
  fi
else
  # Fallback: raw grep (exclude common heavy folders)
  if grep -R --line-number --fixed-strings "${OLD}" . \
      --exclude-dir=.git \
      --exclude-dir=node_modules \
      --exclude-dir=dist \
      --exclude-dir=build \
      --exclude-dir=.next \
      --exclude-dir=.cache \
      --exclude-dir=.vercel \
      --exclude-dir=.netlify ; then
    echo
    echo "❌ Found forbidden legacy license number."
    echo "   Replace with: MI Master Electrician License #6220430"
    exit 1
  fi
fi

echo "✅ OK: legacy license number not found."
