#!/usr/bin/env python3
"""Top Tier Electrical — License Number Sweep

Replaces the legacy license number with the new master license number (6220430),
in a safe, auditable way.

Default behavior:
  - dry-run (no file changes)
  - scans common web/content file types

Exit codes:
  0 = success, no remaining legacy license number
  1 = changes needed / remaining legacy license number found
  2 = unexpected error
"""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Tuple


OLD = "".join(["6","3","1","2","1","0"])  # legacy license number (do not expose in plain text)
NEW = "6220430"

# Preferred public-facing string.
NEW_LABEL = "MI Master Electrician License #6220430"

# File types to scan (add more if your repo uses them).
DEFAULT_EXTS = {
    ".html", ".htm", ".md", ".txt",
    ".js", ".jsx", ".ts", ".tsx",
    ".json", ".yml", ".yaml",
    ".xml", ".csv",
    ".css", ".scss",
    ".toml",
}

DEFAULT_EXCLUDES = {
    "node_modules",
    ".git",
    ".next",
    "dist",
    "build",
    ".cache",
    ".vercel",
    ".netlify",
    "coverage",
    ".turbo",
}


@dataclass
class Change:
    path: Path
    before_sha1: str
    after_sha1: str
    replacements: int


def sha1_bytes(b: bytes) -> str:
    return hashlib.sha1(b).hexdigest()


def iter_files(root: Path, exts: set[str], exclude_dirs: set[str]) -> Iterable[Path]:
    for p in root.rglob("*"):
        if p.is_dir():
            continue
        # Skip excluded directories by path parts.
        if any(part in exclude_dirs for part in p.parts):
            continue
        if p.suffix.lower() in exts:
            yield p


def apply_replacements(text: str) -> Tuple[str, int]:
    """Apply targeted replacements first, then replace any remaining bare OLD only
    when it's clearly license-related.
    """
    total = 0

    patterns: List[Tuple[re.Pattern, str]] = [
        # Common on-site pattern: "MI License #<legacy>"
        (re.compile(r"\bMI\s*License\s*#?\s*" + re.escape(OLD) + r"\b", re.IGNORECASE), NEW_LABEL),

        # Variant: "License #<legacy>" (leave "MI" out to avoid false positives).
        (re.compile(r"\bLicense\s*#?\s*" + re.escape(OLD) + r"\b", re.IGNORECASE), NEW_LABEL),

        # Variant: "Lic #<legacy>" / "Lic. #<legacy>"
        (re.compile(r"\bLic\.?\s*#?\s*" + re.escape(OLD) + r"\b", re.IGNORECASE), NEW_LABEL),
    ]

    new_text = text
    for pat, repl in patterns:
        new_text, n = pat.subn(repl, new_text)
        total += n

    # If OLD remains, only replace when immediately preceded by 'license' within 25 chars.
    if OLD in new_text:
        def _guarded(m: re.Match) -> str:
            return NEW

        guarded = re.compile(r"(?i)(license[^\n]{0,25})" + re.escape(OLD))
        new_text, n2 = guarded.subn(lambda m: m.group(1) + NEW, new_text)
        total += n2

    return new_text, total


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="Project root to scan (default: .)")
    ap.add_argument("--apply", action="store_true", help="Write changes to disk (default: dry-run)")
    ap.add_argument("--ext", action="append", default=[], help="Add an extension to scan (e.g. --ext .php)")
    ap.add_argument("--exclude", action="append", default=[], help="Add an excluded directory name")
    ap.add_argument("--fail-on-remaining", action="store_true", help="Exit non-zero if any legacy license number remains (default: true)")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    exts = set(DEFAULT_EXTS)
    for e in args.ext:
        if not e.startswith("."):
            e = "." + e
        exts.add(e.lower())

    exclude_dirs = set(DEFAULT_EXCLUDES)
    exclude_dirs.update(args.exclude)

    changes: List[Change] = []
    remaining_hits: List[Path] = []

    for f in iter_files(root, exts, exclude_dirs):
        try:
            raw = f.read_bytes()
        except Exception:
            continue

        # Try UTF-8; fall back to latin-1 to avoid crashing.
        try:
            text = raw.decode("utf-8")
            enc = "utf-8"
        except UnicodeDecodeError:
            text = raw.decode("latin-1")
            enc = "latin-1"

        if OLD not in text and ("MI License" not in text and "License" not in text):
            continue

        updated, n = apply_replacements(text)
        if n > 0 and updated != text:
            before = sha1_bytes(raw)
            after_bytes = updated.encode(enc, errors="ignore")
            after = sha1_bytes(after_bytes)
            changes.append(Change(f, before, after, n))

            if args.apply:
                f.write_bytes(after_bytes)

        # Check remaining OLD after targeted replacements (read from disk if apply).
        check_text = updated if not args.apply else f.read_text(encoding=enc, errors="ignore")
        if OLD in check_text:
            remaining_hits.append(f)

    # Reporting
    print("\n=== TopTier License Sweep Report ===")
    print(f"Root: {root}")
    print(f"Mode: {'APPLY' if args.apply else 'DRY-RUN'}")
    print(f"Scanned extensions: {', '.join(sorted(exts))}")
    print(f"Excluded dirs: {', '.join(sorted(exclude_dirs))}\n")

    if changes:
        print(f"Files changed / would change: {len(changes)}")
        for c in changes:
            print(f"- {c.path.relative_to(root)}  (replacements={c.replacements}, sha1 {c.before_sha1[:8]} -> {c.after_sha1[:8]})")
    else:
        print("No files needed changes (based on configured patterns).")

    if remaining_hits:
        print("\n⚠ Remaining occurrences of the legacy license number detected in:")
        for p in sorted(set(remaining_hits)):
            try:
                rp = p.relative_to(root)
            except Exception:
                rp = p
            print(f"- {rp}")
        print("\nThese might be in contexts the script intentionally avoids (to prevent false positives).\n"
              "Search those files manually and replace only if they truly reference the old license.")

    if args.fail_on_remaining or True:
        # Default: fail if remaining occurrences exist.
        return 0 if not remaining_hits else 1

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(2)
