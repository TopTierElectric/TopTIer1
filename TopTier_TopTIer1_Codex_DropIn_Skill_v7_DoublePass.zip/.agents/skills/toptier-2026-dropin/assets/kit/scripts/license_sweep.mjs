/**
 * Top Tier Electrical — License Number Sweep (Node.js)
 *
 * Usage:
 *   node scripts/license_sweep.mjs --root . --apply
 *
 * Default is dry-run.
 */
import fs from "node:fs";
import path from "node:path";

const OLD = ["6","3","1","2","1","0"].join(""); // legacy license number (do not embed as plain text)
const NEW = "6220430";
const NEW_LABEL = "MI Master Electrician License #6220430";

const DEFAULT_EXTS = new Set([
  ".html",".htm",".md",".txt",
  ".js",".jsx",".ts",".tsx",
  ".json",".yml",".yaml",
  ".xml",".csv",
  ".css",".scss",
  ".toml",
]);

const DEFAULT_EXCLUDES = new Set([
  "node_modules",".git",".next","dist","build",".cache",
  ".vercel",".netlify","coverage",".turbo"
]);

function parseArgs(argv){
  const args = { root: ".", apply: false, ext: [], exclude: [] };
  for (let i=2;i<argv.length;i++){
    const a = argv[i];
    if (a === "--root") args.root = argv[++i] ?? ".";
    else if (a === "--apply") args.apply = true;
    else if (a === "--ext") args.ext.push(argv[++i]);
    else if (a === "--exclude") args.exclude.push(argv[++i]);
  }
  return args;
}

function shouldSkip(fullPath, excludeDirs){
  const parts = fullPath.split(path.sep);
  return parts.some(p => excludeDirs.has(p));
}

function applyReplacements(text){
  let total = 0;
  const patterns = [
    [new RegExp(`\\bMI\\s*License\\s*#?\\s*${OLD}\\b`, "gi"), NEW_LABEL],
    [new RegExp(`\\bLicense\\s*#?\\s*${OLD}\\b`, "gi"), NEW_LABEL],
    [new RegExp(`\\bLic\\.?\\s*#?\\s*${OLD}\\b`, "gi"), NEW_LABEL],
  ];

  let out = text;
  for (const [re, repl] of patterns){
    const before = out;
    out = out.replace(re, () => { total++; return repl; });
    // total is incremented per match
  }

  // Guarded replace: "...license .... <legacy>" => "...license .... 6220430"
  if (out.includes(OLD)){
    const guarded = new RegExp(`(license[^\\n]{0,25})${OLD}`, "gi");
    out = out.replace(guarded, (m, p1) => { total++; return p1 + NEW; });
  }

  return { out, total };
}

function walk(dir, exts, excludeDirs, files=[]){
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })){
    const fp = path.join(dir, ent.name);
    if (ent.isDirectory()){
      if (excludeDirs.has(ent.name)) continue;
      walk(fp, exts, excludeDirs, files);
    } else {
      const ext = path.extname(ent.name).toLowerCase();
      if (exts.has(ext) && !shouldSkip(fp, excludeDirs)) files.push(fp);
    }
  }
  return files;
}

const args = parseArgs(process.argv);
const root = path.resolve(args.root);
const exts = new Set(DEFAULT_EXTS);
for (const e of args.ext){
  const ext = e.startsWith(".") ? e : "."+e;
  exts.add(ext.toLowerCase());
}
const excludeDirs = new Set(DEFAULT_EXCLUDES);
for (const d of args.exclude) excludeDirs.add(d);

const files = walk(root, exts, excludeDirs);

const changed = [];
const remaining = [];

for (const fp of files){
  let raw;
  try { raw = fs.readFileSync(fp, "utf8"); }
  catch { continue; }

  if (!raw.includes(OLD) && !raw.includes("License")) continue;

  const { out, total } = applyReplacements(raw);
  if (total > 0 && out !== raw){
    changed.push({ fp, total });
    if (args.apply) fs.writeFileSync(fp, out, "utf8");
  }

  const check = args.apply ? fs.readFileSync(fp, "utf8") : out;
  if (check.includes(OLD)) remaining.push(fp);
}

console.log("\n=== TopTier License Sweep (Node) ===");
console.log(`Root: ${root}`);
console.log(`Mode: ${args.apply ? "APPLY" : "DRY-RUN"}`);
console.log(`Files scanned: ${files.length}`);
console.log(`Files changed / would change: ${changed.length}`);
for (const c of changed){
  console.log(`- ${path.relative(root, c.fp)} (replacements=${c.total})`);
}
if (remaining.length){
  console.log("\n⚠ Remaining legacy license occurrences:");
  for (const fp of [...new Set(remaining)]){
    console.log(`- ${path.relative(root, fp)}`);
  }
  process.exitCode = 1;
} else {
  console.log("\n✅ No remaining legacy license occurrences detected.");
}
