/**
 * TopTier 2026 Refresh (drop-in)
 * - Lightweight GA4/GTM event wiring
 * - Sticky CTA show/hide (mobile)
 * - Simple UTM capture into forms (hidden inputs)
 *
 * Add data-tt-event="event_name" to any element to track clicks.
 * Add data-tt-label="..." for extra label.
 */
(function(){
  const TT = window.TT || (window.TT = {});
  const w = window;

  // ---- Config (edit these) ----
  TT.analytics = {
    // If you use GTM, leave ga4_measurement_id empty and set gtm_container_id.
    gtm_container_id: "GTM-XXXXXXX",
    ga4_measurement_id: "", // e.g. "G-XXXXXXXXXX"
    debug: false
  };

  // ---- Helpers ----
  function log(){ if(TT.analytics.debug) console.log("[TT]", ...arguments); }

  function pushDataLayer(evt){
    w.dataLayer = w.dataLayer || [];
    w.dataLayer.push(evt);
    log("dataLayer push", evt);
  }

  function ga4Event(name, params){
    if(typeof w.gtag === "function"){
      w.gtag("event", name, params || {});
      log("gtag event", name, params);
    }else{
      pushDataLayer({ event: name, ...(params||{}) });
    }
  }

  // ---- Track common conversions ----
  function wireClicks(){
    // Tel / SMS / mailto
    document.querySelectorAll('a[href^="tel:"]').forEach(a=>{
      a.addEventListener("click", ()=>{
        ga4Event("click_to_call", { link_url: a.href, link_text: (a.textContent||"").trim() });
      });
    });

    document.querySelectorAll('a[href^="sms:"], a[href*="text"]').forEach(a=>{
      a.addEventListener("click", ()=>{
        ga4Event("click_to_text", { link_url: a.href, link_text: (a.textContent||"").trim() });
      });
    });

    document.querySelectorAll('a[href^="mailto:"]').forEach(a=>{
      a.addEventListener("click", ()=>{
        ga4Event("click_email", { link_url: a.href, link_text: (a.textContent||"").trim() });
      });
    });

    // Generic click tracking
    document.querySelectorAll("[data-tt-event]").forEach(el=>{
      el.addEventListener("click", ()=>{
        const name = el.getAttribute("data-tt-event");
        const label = el.getAttribute("data-tt-label") || (el.textContent||"").trim();
        ga4Event(name, { label });
      });
    });
  }

  // ---- UTM capture -> hidden form inputs ----
  function getQuery(){
    try { return new URLSearchParams(w.location.search); }
    catch(e){ return new URLSearchParams(); }
  }

  function ensureHidden(form, name, value){
    let input = form.querySelector('input[name="'+name+'"]');
    if(!input){
      input = document.createElement("input");
      input.type = "hidden";
      input.name = name;
      form.appendChild(input);
    }
    input.value = value || "";
  }

  function wireForms(){
    const q = getQuery();
    const utm = {
      utm_source: q.get("utm_source") || "",
      utm_medium: q.get("utm_medium") || "",
      utm_campaign: q.get("utm_campaign") || "",
      utm_content: q.get("utm_content") || "",
      utm_term: q.get("utm_term") || "",
      gclid: q.get("gclid") || "",
      fbclid: q.get("fbclid") || ""
    };

    document.querySelectorAll("form").forEach(form=>{
      // only attach if it looks like a lead form (heuristic)
      const hasPhone = form.querySelector('input[type="tel"], input[name*="phone" i]');
      const hasEmail = form.querySelector('input[type="email"], input[name*="email" i]');
      if(!hasPhone && !hasEmail) return;

      Object.keys(utm).forEach(k=>ensureHidden(form, k, utm[k]));
      ensureHidden(form, "page_path", w.location.pathname);

      form.addEventListener("submit", ()=>{
        ga4Event("generate_lead", { form_id: form.id || "", page_path: w.location.pathname });
      }, { capture: true });
    });
  }

  // ---- Sticky CTA ----
  function wireStickyCTA(){
    const bar = document.querySelector(".tt-sticky-cta");
    if(!bar) return;
    let last = 0;
    function onScroll(){
      const y = w.scrollY || 0;
      // Show after user scrolls a bit, hide near top
      if(y > 420 && last <= 420){
        bar.classList.add("is-visible");
      }else if(y <= 220 && last > 220){
        bar.classList.remove("is-visible");
      }
      last = y;
    }
    w.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  // ---- Boot ----
  document.addEventListener("DOMContentLoaded", ()=>{
    wireClicks();
    wireForms();
    wireStickyCTA();
  });
})();
