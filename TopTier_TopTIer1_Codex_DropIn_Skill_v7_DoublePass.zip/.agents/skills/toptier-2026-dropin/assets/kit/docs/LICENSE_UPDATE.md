# License Update — TopTier Electrical

**Requirement:** remove the **legacy license number** everywhere it appears (site copy, schema, footer, trust badges, city pages) and ensure the only allowed license string is:

**MI Master Electrician License #6220430**

## Fast path (from repo root)

```bash
# Dry run (no changes)
python3 scripts/license_sweep.py --root .

# Apply changes
python3 scripts/license_sweep.py --root . --apply

# Verify removal (CI-style)
bash scripts/verify_no_old_license.sh
```

## Optional convenience runner

```bash
bash scripts/license_update.sh .
```

## CI Guardrail

This repo includes a GitHub Actions workflow:
`.github/workflows/license-guard.yml`

It fails CI if the legacy license number appears anywhere, preventing regressions.

## After deploy

- Purge CDN cache (if applicable).
- Google Search Console: request re-index for:
  - `/` (home)
  - `/services`
  - `/panel-upgrades`, `/ev-chargers`, `/lighting`, `/generators`, etc.
- Re-test schema in Google Rich Results Test.
