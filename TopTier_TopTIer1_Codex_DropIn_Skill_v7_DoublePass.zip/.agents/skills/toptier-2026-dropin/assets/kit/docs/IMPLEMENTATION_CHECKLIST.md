# Top Tier Electrical — 2026 Refresh Integration Checklist

This packet is meant to be **dropped into the TopTier1 repo** and wired up page-by-page.
It upgrades: **images, layout polish, tracking, schema, and GBP alignment**.

---

## 0) Repo prep (do this first)
1. Create a branch:
   - `git checkout -b feat/2026-refresh`
2. Install & run existing checks (per repo README):
   - `npm ci`
   - run the repo’s lint / htmlvalidate / pa11y steps (whatever is configured)
3. Confirm deploy target is the live domain:
   - `https://toptier-electrical.com/`

---

---
## License number update (sitewide trust + schema)

**Remove the old license everywhere it appears (header trust strip + footer + schema).**
**Use ONLY: MI Master Electrician License #6220430**

Implementation (do this once, sitewide):
1. Search the repo for the old license strings and remove/replace them everywhere:
   - `MI License #`
   - `MI License`
   - `License #`
2. Replace with the new trust string:
   - `MI Master Electrician License #6220430`
3. In JSON-LD, ensure `snippets/schema/localbusiness.json` includes ONLY the master license identifier (this pack now does).

## 1) Add assets from this pack into the repo
Copy these folders into the repo root:

- `css/tt2026.css`
- `js/tt2026.js`
- `assets/images/optimized/*`
- `assets/og/og-default.jpg` + `.webp`
- `manifest/images.json`
- `snippets/*` (for copy/paste)

**Keep existing images** for now. We’ll swap references page-by-page.

---

## 2) Head integration (global)
On every HTML page (home, services, service pages, service areas, blog, booking, contact):

1. Add `tt2026.css` AFTER existing CSS links:
   ```html
   <link rel="stylesheet" href="/css/tt2026.css?v=2026-01">
   ```

2. Add `tt2026.js` before closing `</head>` or before `</body>` (defer):
   ```html
   <script src="/js/tt2026.js?v=2026-01" defer></script>
   ```

3. Add a default OG image (or per-page OG later):
   ```html
   <meta property="og:image" content="https://toptier-electrical.com/assets/og/og-default.jpg">
   <meta property="og:image:width" content="1200">
   <meta property="og:image:height" content="630">
   ```

4. Add LocalBusiness schema sitewide (footer include is fine):
   - Use `snippets/schema/localbusiness.json`
   - Replace GBP CID once known.

---

## 3) Page-by-page image swaps (high impact)
Use `<picture>` so Google gets a clean fallback and users get WebP/AVIF.

### Example: replace hero `<img src="/assets/images/hero.jpg">` with:
```html
<picture>
  <source type="image/avif" srcset="/assets/images/optimized/hero-640.avif 640w, /assets/images/optimized/hero-1280.avif 1280w, /assets/images/optimized/hero-1600.avif 1600w" sizes="(max-width: 980px) 100vw, 42vw">
  <source type="image/webp" srcset="/assets/images/optimized/hero-640.webp 640w, /assets/images/optimized/hero-1280.webp 1280w, /assets/images/optimized/hero-1600.webp 1600w" sizes="(max-width: 980px) 100vw, 42vw">
  <img src="/assets/images/optimized/hero-1280.jpg" width="1280" height="960" alt="Top Tier Electrical services at work in West Michigan" loading="eager" fetchpriority="high" decoding="async">
</picture>
```

### Swap list (based on the current live site URLs)
- `/assets/images/hero.jpg` → `assets/images/optimized/hero-*`  
- `/assets/images/projects/service-after.jpg` → `assets/images/optimized/service-after-*`
- `/assets/images/projects/panel-work.jpg` → `assets/images/optimized/panel-work-*`
- `/assets/images/projects/control-work.jpg` → `assets/images/optimized/control-work-*`
- `/assets/images/projects/kitchen-led.jpg` → `assets/images/optimized/kitchen-led-*`
- `/assets/images/projects/480v-3-phase.jpg` → `assets/images/optimized/480v-3-phase-*`
- `/assets/images/projects/transformer.jpg` → `assets/images/optimized/transformer-*`
- `/assets/images/projects/service-upgrade-before.jpg` → `assets/images/optimized/service-upgrade-before-*`
- `/assets/images/projects/conduit.jpg` → `assets/images/optimized/conduit-*`
- EV stock photo `/assets/images/projects/myenergi-...jpg` → `assets/images/optimized/ev-unsplash-*` (replace with a real EV install photo when available)

---

## 4) Layout integration (incremental / safe)
Add `class="tt2026"` to `<body>` on these pages first:
- Home
- Services hub
- Booking
- Contact

Then move to service pages.

This keeps rollout controlled and prevents “big bang” styling surprises.

---

## 5) Conversion tracking (GA4/GTM)
### Track the 4 money events
In GA4 set these as conversions:
- `generate_lead` (form submit)
- `click_to_call`
- `click_to_text`
- `request_scheduling` (button click)

To track scheduling clicks, add:
```html
<a href="/booking" class="btn" data-tt-event="request_scheduling" data-tt-label="Header CTA">Request Scheduling</a>
```

### GBP tracking
Update Google Business Profile website link and appointment link to include UTMs:
- `?utm_source=google&utm_medium=organic&utm_campaign=gbp`

Your GA4 will now show GBP-origin leads.

---

## 6) Structured data (schema)
Add:
- `LocalBusiness` sitewide (done above)
- `FAQPage` on pages that have FAQs
- `Service` schema on each service page

Do **NOT** invent review stars unless you have real Google review data.

---

## 7) QA before launch
- Mobile: hero + booking form above the fold (no clipping)
- Forms: labels exist, validation works, spam protection present
- Accessibility: focus visible, contrast ≥ 4.5:1 for body text
- Performance: hero uses responsive sources and is preloaded if needed
- SEO: titles unique, canonical correct, schema validates

---

## 8) Deploy
1. Merge the branch.
2. Verify production pages.
3. Check Search Console for coverage + enhancements.

