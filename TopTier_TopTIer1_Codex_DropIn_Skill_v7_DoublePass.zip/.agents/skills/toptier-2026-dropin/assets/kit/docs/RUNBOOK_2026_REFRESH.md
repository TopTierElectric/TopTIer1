# TopTier1 — 2026 Refresh + License Fix Runbook (Hands-On)

This runbook assumes you are in the **TopTIer1** repo root.

## 1) Create a branch
```bash
git checkout -b feat/2026-refresh
```

## 2) Drop the pack into the repo
Copy/merge the contents of this integration kit into the repo root:
- `css/tt2026.css`
- `js/tt2026.js`
- `assets/images/optimized/*`
- `assets/og/*`
- `snippets/*`
- `scripts/*` (license + automation)
- `.github/workflows/license-guard.yml`

## 3) Fix old license number globally (apply)
```bash
python3 scripts/license_sweep.py --root . --apply
bash scripts/verify_no_old_license.sh
```

## 4) Wire up CSS/JS + OG tags + body class on core pages
```bash
# Dry-run first
python3 scripts/tt2026_wire_up.py --root .

# Apply on core pages
python3 scripts/tt2026_wire_up.py --root . --apply
```

## 5) Swap high-impact images (optional but recommended)
```bash
# Dry-run first
python3 scripts/tt2026_image_swaps.py --root .

# Apply
python3 scripts/tt2026_image_swaps.py --root . --apply
```

## 6) Build & test
```bash
npm ci
npm run build || npm run preview || npm run dev
```

## 7) Commit
```bash
git status
git add -A
git commit -m "2026 refresh: add tt2026 assets + replace old license number"
git push -u origin feat/2026-refresh
```

## 8) Validate on staging/preview
- Confirm footer and trust strip show only: **MI Master Electrician License #6220430**
- Confirm no legacy license number anywhere in rendered HTML
- Confirm new OG image renders on link preview
- Confirm hero loads fast (responsive sources)

## 9) Deploy & post-deploy
- Purge cache (if CDN)
- Request re-index in Search Console
- Update GBP website + appointment links with UTMs

---
If paths differ in your repo, use `docs/IMPLEMENTATION_CHECKLIST.md` as the canonical manual mapping.
