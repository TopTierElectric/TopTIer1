# Where the old license appears on the live site (as of Feb 12, 2026)

These are the *specific routes* where **the legacy license number** is visible in page content and/or footer.

**Core pages**
- `/` (home): hero trust line + footer
- `/services`: trust line + footer
- `/booking`: footer
- `/contact`: footer
- `/faq`: footer
- `/gallery`: footer
- `/service-areas`: footer
- `/blog`: footer
- `/emergency`: footer

**Service pages**
- `/panel-upgrades`: trust line + footer
- `/ev-chargers`: trust line + footer
- `/lighting`: trust line + footer
- `/energy-solutions`: trust line + footer
- `/energy-consulting`: trust line + footer
- `/generators`: trust line + footer
- `/electrical-repairs`: footer

**City pages**
- `/electrician-grand-rapids`: footer
- `/electrician-ada`: footer
- `/electrician-allegan`: footer
- `/electrician-holland`: footer
- `/electrician-zeeland`: footer
- `/electrician-hudsonville`: footer

Note: some pages include “the legacy license number” only in the footer; other pages include it in a trust badge line near the top.
