---
name: toptier-2026-dropin
description: Drop in the Top Tier Electrical 2026 website refresh kit, wire up core pages, and enforce the single allowed license string: MI Master Electrician License #6220430.
---

You are working inside the TopTier1 repository (Top Tier Electrical website).

## Objective
Apply the bundled **TopTier 2026 Integration Kit** into this repo in a safe, auditable, production-ready way:

1) Copy in the kit assets (CSS, JS, optimized images, OG image, snippets, docs, scripts, CI guard).
2) Replace/remove **every** occurrence of the **legacy license number** across site content and templates.
3) Ensure the only license string present anywhere in site copy + schema is:
   - **MI Master Electrician License #6220430**
4) Wire up the 2026 CSS/JS on core pages (safe rollout) and optionally across all pages.

## What to run (deterministic)
Use the bundled installer (preferred):

- Apply to repo root (default):
  - `python3 .agents/skills/toptier-2026-dropin/scripts/apply_all.py --apply`

- Apply to a different site root (if your HTML lives in `public/` or similar):
  - `python3 .agents/skills/toptier-2026-dropin/scripts/apply_all.py --apply --root public`

## Acceptance criteria (must pass)
- `bash scripts/verify_no_old_license.sh` passes (no legacy license number anywhere in the repo).
- Core pages include:
  - `/css/tt2026.css?v=2026-01`
  - `/js/tt2026.js?v=2026-01` (deferred)
- `LocalBusiness`/`Electrician` JSON-LD (if present) contains:
  - `MI Master Electrician License #6220430`
- Pages still build/deploy successfully (no broken HTML).



## Double-pass (2 clean runs in a row)
To continuously run all bundled checks/scans and prove **two consecutive error-free passes**, run:

- `python3 .agents/skills/toptier-2026-dropin/scripts/double_pass.py --root .`

This will:
1) Apply the kit (write changes)
2) Run the full scan suite
3) Apply + scan again
4) Fail if pass2 introduces any new repo changes

## Notes
- The installer is **idempotent**: re-running it should not duplicate `<link>`, `<script>`, or body classes.
- Avoid introducing heavy JS frameworks unless required; keep the marketing site static-first.
