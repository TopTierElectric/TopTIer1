#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
shift || true

# Run from repository root.
python3 ".agents/skills/toptier-2026-dropin/scripts/apply_all.py" --root "$ROOT" "$@"
