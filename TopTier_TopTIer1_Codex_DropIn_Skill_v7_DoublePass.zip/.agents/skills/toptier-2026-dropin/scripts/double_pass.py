#!/usr/bin/env python3
"""TopTier 2026 — Double-Pass Gate

Run the full TopTier 2026 installer + scans twice back-to-back.

Success criteria:
  1) Both passes complete with exit code 0.
  2) The second pass produces *no additional repo changes* compared to pass 1.

This script is designed for:
  - Local validation before you commit
  - Codex skill execution when you want "two clean passes" confidence

Usage:
  # Run from repo root
  python3 .agents/skills/toptier-2026-dropin/scripts/double_pass.py --root .

Options:
  --all-pages         Wire up all HTML pages (default: core pages only)
  --skip-image-swaps  Skip the targeted <picture> swaps

Exit codes:
  0 success
  1 non-deterministic (pass2 changed repo) OR scans fail
  2 invalid usage / unexpected error
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def find_repo_root(start: Path) -> Path:
    for p in [start] + list(start.parents):
        if (p / ".git").exists():
            return p
    return start


def run(cmd: list[str], cwd: Path) -> None:
    print(f"\n$ {' '.join(cmd)}")
    subprocess.check_call(cmd, cwd=str(cwd))


def git_status(repo_root: Path) -> str:
    if not (repo_root / ".git").exists():
        return ""
    return subprocess.check_output(["git", "status", "--porcelain"], cwd=str(repo_root), text=True)


def warn_if_git_dirty(repo_root: Path) -> None:
    st = git_status(repo_root)
    if st.strip():
        print("⚠️  Note: git working tree is already dirty before pass1.")
        print("   That's OK — the gate will still verify that pass2 makes *no additional* changes.")


def run_scan_suite(repo_root: Path, target_root: Path, all_pages: bool, skip_image_swaps: bool) -> None:
    """Run *non-writing* scans that must return 0."""
    lic = target_root / "scripts" / "license_sweep.py"
    wire = target_root / "scripts" / "tt2026_wire_up.py"
    imgs = target_root / "scripts" / "tt2026_image_swaps.py"
    ver = target_root / "scripts" / "verify_no_old_license.sh"

    # Legacy license must be gone.
    run(["bash", str(ver)], cwd=repo_root)

    # These should return 0 (no changes needed) after a successful install.
    run(["python3", str(lic), "--root", str(target_root)], cwd=repo_root)

    wcmd = ["python3", str(wire), "--root", str(target_root)]
    if all_pages:
        wcmd.append("--all")
    run(wcmd, cwd=repo_root)

    if not skip_image_swaps:
        run(["python3", str(imgs), "--root", str(target_root)], cwd=repo_root)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="Target project root to update (default: .)")
    ap.add_argument("--all-pages", action="store_true", help="Wire up all HTML pages (default: core pages only)")
    ap.add_argument("--skip-image-swaps", action="store_true", help="Skip the targeted <picture> swaps")
    ap.add_argument("--require-clean-start", action="store_true", help="Fail if git working tree is dirty before pass1")
    args = ap.parse_args()

    target_root = Path(args.root).resolve()
    repo_root = find_repo_root(target_root)

    print("=== TopTier Double-Pass Gate ===")
    print(f"Repo root:   {repo_root}")
    print(f"Target root: {target_root}")

    warn_if_git_dirty(repo_root)
    if args.require_clean_start:
        if git_status(repo_root).strip():
            print("❌ Refusing to run: git working tree is not clean (require-clean-start).")
            return 2

    skill_root = Path(__file__).resolve().parents[1]
    installer = skill_root / "scripts" / "apply_all.py"
    if not installer.exists():
        print(f"❌ Missing installer: {installer}")
        return 2

    def run_installer_pass(pass_no: int) -> None:
        print(f"\n--- PASS {pass_no}: APPLY + VERIFY ---")
        cmd = [
            "python3",
            str(installer),
            "--apply",
            "--allow-dirty",  # pass2 must be allowed to run on the dirty tree created by pass1
            "--root",
            str(target_root),
        ]
        if args.all_pages:
            cmd.append("--all-pages")
        if args.skip_image_swaps:
            cmd.append("--skip-image-swaps")
        run(cmd, cwd=repo_root)

        print(f"\n--- PASS {pass_no}: SCAN SUITE (must be clean) ---")
        run_scan_suite(repo_root, target_root, all_pages=args.all_pages, skip_image_swaps=args.skip_image_swaps)
        print(f"✅ PASS {pass_no} OK")

    # PASS 1
    run_installer_pass(1)
    status_after_1 = git_status(repo_root)

    # PASS 2
    run_installer_pass(2)
    status_after_2 = git_status(repo_root)

    if status_after_1 != status_after_2:
        print("\n❌ FAIL: pass2 introduced additional changes (non-idempotent).")
        print("--- git status after pass1 ---")
        print(status_after_1.rstrip() or "(clean)")
        print("--- git status after pass2 ---")
        print(status_after_2.rstrip() or "(clean)")
        return 1

    print("\n✅ SUCCESS: two consecutive error-free passes, and pass2 produced no new changes.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except subprocess.CalledProcessError as e:
        # bubble up command failures as a clear error code
        raise SystemExit(e.returncode or 1)
