#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
shift || true

python3 ".agents/skills/toptier-2026-dropin/scripts/double_pass.py" --root "$ROOT" "$@"
