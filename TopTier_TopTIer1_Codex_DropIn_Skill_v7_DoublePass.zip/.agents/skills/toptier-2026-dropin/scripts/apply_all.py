#!/usr/bin/env python3
"""TopTier 2026 — Codex Drop-in Installer (Repo-safe)

What this installer does (deterministic + idempotent):

1) Copies the bundled kit from:
   .agents/skills/toptier-2026-dropin/assets/kit/*
   into your repo root (or --root) WITHOUT creating backup files.

   Rationale: This is a git repo — you can revert with git if needed.
   Backup files can accidentally reintroduce forbidden legacy license numbers.

2) Runs, in order:
   - scripts/license_sweep.py
   - scripts/tt2026_wire_up.py
   - scripts/tt2026_image_swaps.py (optional)

3) Verifies the legacy license number is not present using:
   - scripts/verify_no_old_license.sh

Usage:
  # Dry-run (no writes)
  python3 .agents/skills/toptier-2026-dropin/scripts/apply_all.py

  # Apply
  python3 .agents/skills/toptier-2026-dropin/scripts/apply_all.py --apply
"""

from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

NEW_LABEL = "MI Master Electrician License #6220430"

# Legacy license number computed without embedding as a contiguous literal.
OLD = "".join(["6", "3", "1", "2", "1", "0"])

# Common heavy / generated folders to ignore for sanity checks.
EXCLUDE_DIRS = {
    ".git", "node_modules", "dist", "build", ".next", ".cache", ".vercel", ".netlify",
    ".turbo", "coverage",
}


def find_repo_root(start: Path) -> Path:
    for p in [start] + list(start.parents):
        if (p / ".git").exists():
            return p
    return start


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def is_git_clean(repo_root: Path) -> bool:
    if not (repo_root / ".git").exists():
        return True
    try:
        out = subprocess.check_output(["git", "status", "--porcelain"], cwd=str(repo_root), text=True)
        return out.strip() == ""
    except Exception:
        # If git isn't available for some reason, don't block.
        return True


def copy_kit(kit_root: Path, target_root: Path, apply: bool, skip_existing: bool) -> list[str]:
    actions: list[str] = []
    for src in kit_root.rglob("*"):
        if src.is_dir():
            continue

        rel = src.relative_to(kit_root)

        # Skip macOS junk files
        if src.name == ".DS_Store":
            continue

        # Skip excluded dirs inside the kit path (rare)
        if any(part in EXCLUDE_DIRS for part in rel.parts):
            continue

        dst = target_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)

        if dst.exists():
            if dst.is_dir():
                actions.append(f"conflict (dst is dir): {rel.as_posix()}")
                continue

            same = False
            try:
                same = sha256_file(src) == sha256_file(dst)
            except Exception:
                same = False

            if same:
                actions.append(f"unchanged: {rel.as_posix()}")
                continue

            if skip_existing:
                actions.append(f"skipped-existing: {rel.as_posix()}")
                continue

            if apply:
                shutil.copy2(src, dst)
                actions.append(f"overwritten: {rel.as_posix()}")
            else:
                actions.append(f"would-overwrite: {rel.as_posix()}")
        else:
            if apply:
                shutil.copy2(src, dst)
                actions.append(f"created: {rel.as_posix()}")
            else:
                actions.append(f"would-create: {rel.as_posix()}")

    return actions


def run(cmd: list[str], cwd: Path) -> None:
    print(f"\n$ {' '.join(cmd)}")
    subprocess.check_call(cmd, cwd=str(cwd))


def assert_no_old_license(root: Path) -> None:
    # Light sanity scan across common text files (independent of git).
    exts = {
        ".html", ".htm", ".md", ".txt",
        ".js", ".jsx", ".ts", ".tsx", ".mjs",
        ".json", ".yml", ".yaml", ".xml",
        ".css", ".scss", ".toml",
    }
    hits: list[Path] = []
    for p in root.rglob("*"):
        if p.is_dir():
            continue
        if any(part in EXCLUDE_DIRS for part in p.parts):
            continue
        if p.suffix.lower() not in exts:
            continue
        try:
            data = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if OLD in data:
            hits.append(p)

    if hits:
        print("\n❌ ERROR: Legacy license number still present in:")
        for h in hits[:50]:
            try:
                print(f"- {h.relative_to(root)}")
            except Exception:
                print(f"- {h}")
        raise SystemExit(1)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="Write changes to disk (default: dry-run)")
    ap.add_argument("--root", default=".", help="Target project root to update (default: .)")
    ap.add_argument("--all-pages", action="store_true", help="Wire-up all HTML pages (default: only core pages)")
    ap.add_argument("--skip-image-swaps", action="store_true", help="Skip the image <picture> swaps step")
    ap.add_argument("--skip-existing", action="store_true", help="Do not overwrite files that already exist")
    ap.add_argument("--allow-dirty", action="store_true", help="Allow running even if git working tree is dirty")
    args = ap.parse_args()

    target_root = Path(args.root).resolve()
    repo_root = find_repo_root(target_root)

    print("=== TopTier 2026 Codex Drop-in Installer ===")
    print(f"Repo root:   {repo_root}")
    print(f"Target root: {target_root}")
    print(f"Mode:        {'APPLY' if args.apply else 'DRY-RUN'}")
    print(f"Allowed license string: {NEW_LABEL}\n")

    if args.apply and not args.allow_dirty and not is_git_clean(repo_root):
        print("❌ Refusing to run: git working tree is not clean.")
        print("   Commit/stash your changes first, or re-run with --allow-dirty.")
        return 2

    skill_root = Path(__file__).resolve().parents[1]
    kit_root = skill_root / "assets" / "kit"
    if not kit_root.exists():
        print(f"❌ Kit root not found: {kit_root}")
        return 2

    print("\n--- Step 1: Copy kit into target root ---")
    actions = copy_kit(kit_root, target_root, apply=args.apply, skip_existing=args.skip_existing)
    # Small, readable summary
    created = sum(a.startswith("created:") for a in actions)
    overwritten = sum(a.startswith("overwritten:") for a in actions)
    skipped = sum(a.startswith("skipped-existing:") for a in actions)
    unchanged = sum(a.startswith("unchanged:") for a in actions)
    would_create = sum(a.startswith("would-create:") for a in actions)
    would_overwrite = sum(a.startswith("would-overwrite:") for a in actions)

    print(f"Files summary: created={created} overwritten={overwritten} skipped_existing={skipped} unchanged={unchanged} would_create={would_create} would_overwrite={would_overwrite}")
    if not args.apply:
        print("Dry-run: no files written.")

    # Ensure scripts exist where expected.
    lic = target_root / "scripts" / "license_sweep.py"
    wire = target_root / "scripts" / "tt2026_wire_up.py"
    imgs = target_root / "scripts" / "tt2026_image_swaps.py"
    ver = target_root / "scripts" / "verify_no_old_license.sh"

    missing = [p for p in [lic, wire, imgs, ver] if not p.exists()]
    if missing:
        print("\n❌ Missing expected kit scripts (copy step likely skipped/blocked):")
        for m in missing:
            print(f"- {m}")
        return 2

    print("\n--- Step 2: License sweep (remove legacy license number) ---")
    cmd = ["python3", str(lic), "--root", str(target_root)]
    if args.apply:
        cmd.append("--apply")
    run(cmd, cwd=repo_root)

    print("\n--- Step 3: Wire up CSS/JS + OG defaults ---")
    cmd = ["python3", str(wire), "--root", str(target_root)]
    if args.apply:
        cmd.append("--apply")
    if args.all_pages:
        cmd.append("--all")
    run(cmd, cwd=repo_root)

    if not args.skip_image_swaps:
        print("\n--- Step 4: Image swaps (<picture> blocks for legacy paths) ---")
        cmd = ["python3", str(imgs), "--root", str(target_root)]
        if args.apply:
            cmd.append("--apply")
        run(cmd, cwd=repo_root)
    else:
        print("\n--- Step 4: Image swaps skipped ---")

    print("\n--- Step 5: Verify legacy license removed ---")
    if args.apply:
        # Prefer the kit verifier (git-aware).
        run(["bash", str(ver)], cwd=repo_root)
        # Extra sanity scan (defense-in-depth)
        assert_no_old_license(target_root)

    print("\n✅ Done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())