# TopTier 2026 Drop-in (Codex Skill)

## Quick use (human)
From repo root:

```bash
python3 .agents/skills/toptier-2026-dropin/scripts/apply_all.py --apply
```

Optional:
- Wire up all HTML pages:
  ```bash
  python3 .agents/skills/toptier-2026-dropin/scripts/apply_all.py --apply --all-pages
  ```
- Skip targeted image swaps:
  ```bash
  python3 .agents/skills/toptier-2026-dropin/scripts/apply_all.py --apply --skip-image-swaps
  ```

## Quick use (Codex)
In Codex CLI/IDE:
- Use `/skills` then select **TopTier 2026 Drop-in**, or mention `$toptier-2026-dropin`.
- Ask: “Apply the TopTier 2026 kit to this repo.”


## Double-pass gate (two error-free runs in a row)
From repo root:

```bash
python3 .agents/skills/toptier-2026-dropin/scripts/double_pass.py --root .
```

This runs apply + scan twice and fails if the second pass changes anything.
