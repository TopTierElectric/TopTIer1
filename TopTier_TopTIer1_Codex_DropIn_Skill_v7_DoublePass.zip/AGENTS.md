# AGENTS.md — TopTier1

This repo contains the Top Tier Electrical marketing website.

## Non-negotiables
- **License:** The only license number that may appear anywhere in site copy, schema, docs, or templates is:
  - **MI Master Electrician License #6220430**
- A **legacy license number** must never appear anywhere in site copy, schema, docs, or templates.
- Keep changes **idempotent** (re-running scripts should not duplicate tags/markup).
- Favor performance-first changes: static HTML/CSS/JS, minimal JavaScript, optimized images.

## Available Codex skill in this repo
- `toptier-2026-dropin` (see `.agents/skills/toptier-2026-dropin/`)
  - Drops in the 2026 visual/performance/SEO kit
  - Removes the legacy license number everywhere
  - Wires up CSS/JS + OG defaults on core pages
  - Adds a CI guard to prevent regressions

## Suggested workflow
1. Create a branch: `feat/2026-refresh`
2. Run the skill apply script:
   - `python3 .agents/skills/toptier-2026-dropin/scripts/apply_all.py --apply`
3. Verify the legacy license number is fully removed:
   - `bash scripts/verify_no_old_license.sh`
4. Run build/test if applicable.
