# TopTier1 Patch Pack — 2026-02-08

This patch pack is aligned to your provided attachment (Update Pack + Full Audit/SOP) and includes:

- 5 new AEO-ready pages (2 audience hubs + 3 commercial pages)
- A Cloudflare Pages `_redirects` file (no Netlify tokens)
- Static `sitemap.xml` + `robots.txt`
- Optional: owned form endpoint via Cloudflare Pages Functions + Turnstile + thank-you page
- Optional: CI guardrails to prevent redirect regressions

## Files

### Pages
- `residential-electrician-allegan-mi.html`
- `commercial-electrician-allegan-mi.html`
- `commercial-led-lighting-retrofit.html`
- `commercial-electrical-maintenance.html`
- `electrical-design-consultation.html`

### Redirects + SEO
- `_redirects`
- `sitemap.xml`
- `robots.txt`

### Forms (optional)
- `functions/api/form.ts`
- `thank-you.html`

### Guardrails (optional)
- `scripts/check-redirects-cloudflare.mjs`
- `redirect-guards.workflow.example.yml`

## Required follow-up edits (existing site)

1) **Home + Services linking**
   - Add “Choose your path: Residential / Commercial” cards linking to:
     - `/residential-electrician-allegan-mi`
     - `/commercial-electrician-allegan-mi`

2) **Internal linking**
   - Update your global nav + in-page links to extensionless URLs (`/services`, not `/services.html`).

3) **Fix `/financing.html`**
   - Keep canonical: `/financing`
   - Ensure `/financing.html` redirects to `/financing` (already included).

4) **Turnstile**
   - Replace `__TURNSTILE_SITE_KEY__` in the two hub pages.
   - Add `TURNSTILE_SECRET_KEY` in Cloudflare Pages environment variables.

## Deployment notes (Cloudflare Pages)

- Place `_redirects`, `sitemap.xml`, and the HTML pages in the Pages output root.

- After deploy:
  - Verify `https://toptier-electrical.com/sitemap.xml` returns 200.
  - Verify hubs load at extensionless URLs:
    - `/residential-electrician-allegan-mi`
    - `/commercial-electrician-allegan-mi`
