\
    # Apply this pack into an existing repo working tree (run from the repo root).
    # Usage (PowerShell):
    #   powershell -ExecutionPolicy Bypass -File .\APPLY_TO_REPO.ps1

    $here = Split-Path -Parent $MyInvocation.MyCommand.Path

    if (!(Test-Path ".git")) {
      Write-Error "Run this from the repo root (where .git exists)."
      exit 1
    }

    function Sync-Folder($src, $dst) {
      if (!(Test-Path $dst)) { New-Item -ItemType Directory -Force -Path $dst | Out-Null }
      robocopy $src $dst /MIR /NFL /NDL /NJH /NJS /NP | Out-Null
    }

    Sync-Folder "$here\public" ".\public"
    Sync-Folder "$here\functions" ".\functions"
    Sync-Folder "$here\scripts" ".\scripts"
    Sync-Folder "$here\.github" ".\.github"
    Sync-Folder "$here\cloudflare" ".\cloudflare"
    Sync-Folder "$here\docs" ".\docs"

    Copy-Item "$here\README_FINAL.md" ".\README_FINAL.md" -Force
    if (Test-Path "$here\README_IMPLEMENTATION.md") { Copy-Item "$here\README_IMPLEMENTATION.md" ".\README_IMPLEMENTATION.md" -Force }
    if (Test-Path "$here\wrangler.toml.example") { Copy-Item "$here\wrangler.toml.example" ".\wrangler.toml.example" -Force }

    Write-Host ""
    Write-Host "Pack applied. Next:"
    Write-Host "  git status"
    Write-Host "  npm ci; npm run build"
    Write-Host "  $env:PAGES_OUTPUT_DIR='dist'; node scripts/check-redirects-cloudflare.mjs"
    Write-Host "  $env:PAGES_OUTPUT_DIR='dist'; node scripts/check-navigation-sim.mjs"
