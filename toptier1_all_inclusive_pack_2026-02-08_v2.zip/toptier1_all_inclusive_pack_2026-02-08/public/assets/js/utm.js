// Populate hidden UTM fields + current page URL into any form that includes these input names.
// Usage: add to your global JS bundle or include on pages with forms.
(function () {
  try {
    var qs = new URLSearchParams(window.location.search || "");
    var keys = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term", "gclid"];

    keys.forEach(function (k) {
      var v = qs.get(k);
      if (!v) return;
      document.querySelectorAll('input[name="' + k + '"]').forEach(function (el) {
        if (!el.value) el.value = v;
      });
    });

    document.querySelectorAll('input[name="page"]').forEach(function (el) {
      if (!el.value) el.value = window.location.href;
    });
  } catch (e) {
    // no-op
  }
})();
