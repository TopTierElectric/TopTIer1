/**
 * TopTier1 site helpers (SOP-compliant: keep logic external, avoid inline scripts).
 * - Sets footer year
 * - Relays click events to GA4 (gtag) if present
 * - Captures UTMs into hidden form fields
 */
(function () {
  function setYear() {
    var y = document.getElementById("y");
    if (y) y.textContent = String(new Date().getFullYear());
  }

  function bindGaRelay() {
    document.addEventListener("click", function (e) {
      var el = e.target && e.target.closest ? e.target.closest("[data-ga-event]") : null;
      if (!el) return;
      if (typeof window.gtag !== "function") return;

      window.gtag("event", el.getAttribute("data-ga-event"), {
        event_label: el.getAttribute("data-ga-label") || "",
        destination: el.getAttribute("data-ga-destination") || ""
      });
    });
  }

  function captureUtm() {
    var p = new URLSearchParams(window.location.search || "");
    var keys = ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"];
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      var v = p.get(k);
      if (!v) continue;
      var el = document.querySelector('input[name="' + k + '"]');
      if (el) el.value = v;
    }
  }

  function init() {
    setYear();
    bindGaRelay();
    captureUtm();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
