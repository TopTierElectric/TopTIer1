# Image Source Record Template (audit-ready)

- File (final): `assets/img/<name>.avif` (and `.webp` fallback)
- Original source URL:
- License / usage rights:
- Date downloaded:
- Attribution required? (Y/N)
- Notes (model/location releases, restrictions):
