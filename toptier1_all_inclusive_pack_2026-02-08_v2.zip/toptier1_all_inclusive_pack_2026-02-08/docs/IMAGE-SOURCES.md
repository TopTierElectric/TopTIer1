# Image Sources Log (SOP)

Use this file to track every image in the repo for auditability and licensing clarity.

## Entry template

- File: `/assets/img/<filename>`
- Source URL:
- License / permission:
- Created by / Photographer:
- Date acquired:
- Notes (edits, compression, resizing):

## Notes
- Prefer original photos you own.
- Keep filenames stable (cache-friendly).
- If you replace an image, keep a record of the previous source.
