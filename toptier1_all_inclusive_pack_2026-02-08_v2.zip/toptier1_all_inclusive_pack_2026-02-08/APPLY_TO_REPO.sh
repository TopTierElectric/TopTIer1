#!/usr/bin/env bash
set -euo pipefail

# Apply this pack into an existing repo working tree (run from the repo root).
#
# Usage:
#   bash APPLY_TO_REPO.sh
#
# Notes:
# - This uses rsync so it merges folders cleanly.
# - It will overwrite existing files with the pack's versions.

here="$(cd "$(dirname "$0")" && pwd)"

if [ ! -d ".git" ]; then
  echo "ERROR: Run this from the repo root (where .git exists)."
  exit 1
fi

rsync -av --delete "$here/public/" ./public/
rsync -av --delete "$here/functions/" ./functions/
rsync -av --delete "$here/scripts/" ./scripts/
rsync -av --delete "$here/.github/" ./.github/
rsync -av --delete "$here/cloudflare/" ./cloudflare/
rsync -av --delete "$here/docs/" ./docs/

# Root docs
cp -f "$here/README_FINAL.md" ./README_FINAL.md
if [ -f "$here/README_IMPLEMENTATION.md" ]; then
  cp -f "$here/README_IMPLEMENTATION.md" ./README_IMPLEMENTATION.md
fi
if [ -f "$here/wrangler.toml.example" ]; then
  cp -f "$here/wrangler.toml.example" ./wrangler.toml.example
fi

# Optional: activate workflows if you prefer (uncomment)
# cp -f "$here/.github/workflows/ci.yml" ./.github/workflows/ci.yml
# cp -f "$here/.github/workflows/deploy-prod.yml" ./.github/workflows/deploy-prod.yml

echo ""
echo "Pack applied. Next:"
echo "  git status"
echo "  npm ci && npm run build"
echo "  PAGES_OUTPUT_DIR=dist node scripts/check-redirects-cloudflare.mjs"
echo "  PAGES_OUTPUT_DIR=dist node scripts/check-navigation-sim.mjs"
