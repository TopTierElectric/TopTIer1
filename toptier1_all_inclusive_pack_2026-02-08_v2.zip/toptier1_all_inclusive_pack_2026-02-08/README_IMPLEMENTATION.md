# TopTier1 SOP‑Compliant Consolidated Pack — 2026-02-08

This package consolidates your update packs into ONE SOP-aligned set of drop-in files:

## Includes
- New pages (5):
  - /residential-electrician-allegan-mi
  - /commercial-electrician-allegan-mi
  - /commercial-led-lighting-retrofit
  - /commercial-electrical-maintenance
  - /electrical-design-consultation
- SEO:
  - _redirects (Cloudflare Pages format)
  - _headers (security + caching baseline)
  - sitemap.xml (static)
  - robots.txt
- Conversion:
  - thank-you.html (noindex)
  - Cloudflare Pages Function: /api/form (Turnstile server-side verify + optional KV store)
- CI guardrails:
  - scripts/check-redirects-cloudflare.mjs
  - scripts/check-navigation-sim.mjs
  - (optional) scripts/check-no-html-links.mjs
  - GitHub workflow examples (rename *.example.yml to activate)

## Where to place files
Your SOP expects _redirects/_headers in the *build output directory*.
Because repos differ, this pack includes BOTH:
- root-level files, and
- a /public/ folder containing the same static files

Use ONE of these patterns:
1) **No-build static repo (output=root):**
   - Copy the root-level files into your repo root.
2) **Framework repo (output=dist, source=public):**
   - Copy the /public folder contents into your repo's public folder.

## Required Cloudflare dashboard steps (P0)
These cannot be done in-repo:
- Bulk Redirects / Zone Rules:
  - toptier1.pages.dev/*  -> https://toptier-electrical.com/:splat (301)  [include subdomains + preserve query]
  - www.toptier-electrical.com/* -> https://toptier-electrical.com/:splat (301)

## Form configuration (optional but recommended)
1) Replace `__TURNSTILE_SITE_KEY__` on the two hub pages.
2) In Cloudflare Pages project settings:
   - Add env var: TURNSTILE_SECRET_KEY
   - Bind KV namespace: FORM_SUBMISSIONS (optional)

## Validate (98% gate)
- Build and run Pages sim:
  - npx wrangler pages dev <OUTPUT_DIR> --port 8788
- Run guardrails:
  - node scripts/check-redirects-cloudflare.mjs
  - node scripts/check-navigation-sim.mjs
