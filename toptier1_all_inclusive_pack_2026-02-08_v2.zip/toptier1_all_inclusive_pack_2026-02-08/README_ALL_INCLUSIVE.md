# TopTier1 All-Inclusive Pack — 2026-02-08

This ZIP bundles **both** of your provided packs into a single, consolidated, drop-in set.

## What’s inside

- `public/` — deployable static assets (includes `_redirects`, `_headers`, `sitemap.xml`, `robots.txt`, and new pages)
- `functions/` — Cloudflare Pages Function(s) (includes `/api/form`)
- `scripts/` — SOP checks (`check-redirects-cloudflare`, `check-navigation-sim`, plus `check-no-html-links`)
- `.github/` — workflow examples **and** convenience active workflow copies (`ci.yml`, `deploy-prod.yml`)
- `cloudflare/` — Bulk Redirects CSVs:
  - `bulk_redirects_canonical_hosts.csv` (canonical host enforcement)
  - `bulk_redirects_template.csv` (generic template)
- `docs/` — image/source documentation templates + logs
- `snippets/` — reusable HTML snippet(s)
- `packs/` — the original ZIP files (unaltered), included for reference/archive

## How to apply to a repo

From your repo root (where `.git/` exists):

**macOS/Linux**
```bash
bash /path/to/this-pack/APPLY_TO_REPO.sh
```

**Windows (PowerShell)**
```powershell
powershell -ExecutionPolicy Bypass -File \path\to\this-pack\APPLY_TO_REPO.ps1
```

Then verify:
```bash
npm ci
npm run build
PAGES_OUTPUT_DIR=dist node scripts/check-redirects-cloudflare.mjs
PAGES_OUTPUT_DIR=dist node scripts/check-navigation-sim.mjs
```

## Cloudflare Dashboard task (canonical hosts)

Import `cloudflare/bulk_redirects_canonical_hosts.csv` via:
Cloudflare Dashboard → Rules → Bulk Redirects.

Enable:
- preserve query string
- include subdomains
- subpath matching
- preserve path suffix
