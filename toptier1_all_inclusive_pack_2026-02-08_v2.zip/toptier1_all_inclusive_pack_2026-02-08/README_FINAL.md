# TopTier1 Finalization Pack — 2026-02-08

This pack is aligned to your two attachments:
- `Page addition instructions.txt` (hub + commercial page structure + integration sequence)
- `Toptier1_Full_Audit_and_StepByStep_Procedure.md` (routing/headers/CI + 98% confidence gate)

## Drop-in locations
- `public/` contains Pages output assets (`_redirects`, `_headers`, `sitemap.xml`, `robots.txt`, new pages)
- `functions/` contains Pages Functions (`/api/form`)
- `scripts/` contains CI guard scripts

## Critical environment bindings
- `TURNSTILE_SECRET_KEY` (Pages env var)
- `FORM_SUBMISSIONS` KV binding (recommended)

## Canonical host enforcement
Import `cloudflare/bulk_redirects_canonical_hosts.csv` into Cloudflare Rules → Bulk Redirects and enable:
- Preserve query string
- Include subdomains
- Subpath matching
- Preserve path suffix

## Verification (98% confidence)
Run (adjust output dir as needed):
```bash
npm ci
npm run build
PAGES_OUTPUT_DIR=dist node scripts/check-redirects-cloudflare.mjs
PAGES_OUTPUT_DIR=dist node scripts/check-navigation-sim.mjs
npx lighthouse http://127.0.0.1:8788/ --only-categories=performance,seo,accessibility,best-practices
```
