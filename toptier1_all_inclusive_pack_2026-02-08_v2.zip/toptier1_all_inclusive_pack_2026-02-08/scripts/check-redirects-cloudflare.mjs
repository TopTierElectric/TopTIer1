import fs from "node:fs";
import path from "node:path";

const OUT_DIR = process.env.PAGES_OUTPUT_DIR || "dist"; // adjust to your build output
const redirectsPath = path.join(OUT_DIR, "_redirects");

if (!fs.existsSync(redirectsPath)) {
  console.log(`[redirects] no ${redirectsPath} found (ok for repos that don’t use _redirects).`);
  process.exit(0);
}

const content = fs.readFileSync(redirectsPath, "utf8");

// 1) reject invalid Netlify-style markers like "301!"
const badBang = content.match(/\b\d{3}!\b/g);
if (badBang?.length) {
  console.error(`[redirects] Invalid status token(s) found: ${[...new Set(badBang)].join(", ")}`);
  console.error(`[redirects] Fix: replace 301! -> 301 (Cloudflare requires numeric status codes).`);
  process.exit(1);
}

// 2) basic line format validation: ignore blank lines and comments
const lines = content.split(/\r?\n/);
let failed = false;

for (let i = 0; i < lines.length; i++) {
  const raw = lines[i].trim();
  if (!raw || raw.startsWith("#")) continue;

  // Split on whitespace
  const parts = raw.split(/\s+/);

  // Cloudflare: [source] [destination] [code?]
  if (parts.length < 2 || parts.length > 3) {
    console.error(`[redirects] Line ${i + 1} invalid token count: "${lines[i]}"`);
    failed = true;
    continue;
  }

  // If code exists, must be numeric
  if (parts.length === 3 && !/^\d{3}$/.test(parts[2])) {
    console.error(`[redirects] Line ${i + 1} invalid status code: "${lines[i]}"`);
    failed = true;
  }
}

if (failed) process.exit(1);

console.log("[redirects] OK");
process.exit(0);
