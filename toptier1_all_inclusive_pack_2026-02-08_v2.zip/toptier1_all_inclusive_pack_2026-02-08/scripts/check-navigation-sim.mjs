import { spawn } from "node:child_process";

const BASE = "http://127.0.0.1:8788";
const OUTPUT_DIR = process.env.PAGES_OUTPUT_DIR || "dist";
const SEED_PATHS = ["/"]; // add "/services", "/contact" etc

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function fetchOk(url, opts = {}) {
  const res = await fetch(url, { redirect: "follow", ...opts });
  return res;
}

function extractInternalLinks(html) {
  // Light-weight link extraction (works for static HTML)
  const links = new Set();
  const re = /href\s*=\s*["']([^"']+)["']/gi;
  let m;
  while ((m = re.exec(html))) {
    const href = m[1].trim();
    if (!href) continue;
    if (href.startsWith("mailto:") || href.startsWith("tel:")) continue;
    if (href.startsWith("#")) continue;
    if (href.startsWith("http://") || href.startsWith("https://")) continue; // external
    // Normalize relative to root
    const normalized = href.startsWith("/") ? href : `/${href.replace(/^\.\//, "")}`;
    links.add(normalized.split("?")[0].split("#")[0]);
  }
  return [...links];
}

async function main() {
  // Start wrangler pages dev
  const child = spawn(
    "npx",
    ["wrangler", "pages", "dev", OUTPUT_DIR, "--port", "8788"],
    { stdio: "inherit" }
  );

  // Give it a moment to boot
  await sleep(2500);

  try {
    const toCheck = new Set(SEED_PATHS);
    const checked = new Set();

    // Crawl shallowly: fetch each html page once and extract links
    while (toCheck.size) {
      const path = toCheck.values().next().value;
      toCheck.delete(path);

      if (checked.has(path)) continue;
      checked.add(path);

      const url = `${BASE}${path}`;
      const res = await fetchOk(url);

      if (res.status >= 400) {
        throw new Error(`[nav] FAIL ${path} -> HTTP ${res.status}`);
      }

      const ct = res.headers.get("content-type") || "";
      if (ct.includes("text/html")) {
        const html = await res.text();
        for (const l of extractInternalLinks(html)) {
          // only crawl site pages (not images/css/js)
          if (/\.(png|jpe?g|webp|avif|svg|css|js|pdf)$/i.test(l)) continue;
          toCheck.add(l);
        }
      }
    }

    // Final pass: ensure everything resolves (including non-HTML routes)
    for (const path of checked) {
      const res = await fetchOk(`${BASE}${path}`);
      if (res.status >= 400) {
        throw new Error(`[nav] FAIL final ${path} -> HTTP ${res.status}`);
      }
    }

    console.log(`[nav] OK (${checked.size} routes checked)`);
  } finally {
    child.kill("SIGTERM");
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
