/**
 * Optional lint: fail if internal hrefs contain ".html" (except allowed legacy).
 * Run: node scripts/check-no-html-links.mjs dist
 */
import fs from "node:fs";
import path from "node:path";

const OUT_DIR = process.argv[2] || process.env.PAGES_OUTPUT_DIR || "dist";

function walk(dir) {
  const out = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walk(p));
    else out.push(p);
  }
  return out;
}

const files = walk(OUT_DIR).filter((p) => p.endsWith(".html"));
let failed = false;

for (const f of files) {
  const html = fs.readFileSync(f, "utf8");
  // internal links ending with .html
  const hits = html.match(/href\s*=\s*["'](\/[^"']+\.html)["']/gi);
  if (hits && hits.length) {
    console.error(`[no-html-links] ${path.relative(OUT_DIR, f)} has internal .html links:`);
    for (const h of hits.slice(0, 10)) console.error(`  ${h}`);
    if (hits.length > 10) console.error(`  ...and ${hits.length - 10} more`);
    failed = true;
  }
}

if (failed) process.exit(1);
console.log("[no-html-links] OK");
