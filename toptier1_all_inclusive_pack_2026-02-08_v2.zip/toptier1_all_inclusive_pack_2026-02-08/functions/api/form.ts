export interface Env {
  TURNSTILE_SECRET_KEY: string;
  // Optional KV binding name example: FORM_SUBMISSIONS
  FORM_SUBMISSIONS?: KVNamespace;
}

/**
 * Cloudflare Pages Function
 * Route: /api/form  (functions/api/form.ts)
 */
export const onRequestPost: PagesFunction<Env> = async (context) => {
  const { request, env } = context;

  const contentType = request.headers.get('content-type') || '';
  if (!contentType.includes('application/x-www-form-urlencoded') && !contentType.includes('multipart/form-data')) {
    return new Response('Unsupported content-type', { status: 415 });
  }

  const form = await request.formData();

  // Turnstile token is sent as 'cf-turnstile-response'
  const token = String(form.get('cf-turnstile-response') || '').trim();
  if (!token) {
    return new Response('Missing Turnstile token', { status: 400 });
  }

  // Verify Turnstile token server-side (mandatory)
  const ip = request.headers.get('CF-Connecting-IP') || '';
  const verifyBody = new URLSearchParams();
  verifyBody.set('secret', env.TURNSTILE_SECRET_KEY);
  verifyBody.set('response', token);
  if (ip) verifyBody.set('remoteip', ip);

  const verifyResp = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: verifyBody.toString(),
  });

  if (!verifyResp.ok) {
    return new Response('Turnstile verification failed', { status: 502 });
  }

  const verifyJson: any = await verifyResp.json();
  if (!verifyJson.success) {
    return new Response('Invalid Turnstile token', { status: 403 });
  }

  const payload = {
    received_at: new Date().toISOString(),
    page: String(form.get('page') || ''),
    name: String(form.get('name') || ''),
    email: String(form.get('email') || ''),
    phone: String(form.get('phone') || ''),
    service: String(form.get('service') || ''),
    message: String(form.get('message') || ''),
    utm: {
      source: String(form.get('utm_source') || ''),
      medium: String(form.get('utm_medium') || ''),
      campaign: String(form.get('utm_campaign') || ''),
      term: String(form.get('utm_term') || ''),
      content: String(form.get('utm_content') || ''),
    },
    ip,
    user_agent: request.headers.get('user-agent') || '',
    referrer: request.headers.get('referer') || '',
  };

  // Store in KV if available
  if (env.FORM_SUBMISSIONS) {
    const key = `lead:${Date.now()}:${crypto.randomUUID()}`;
    await env.FORM_SUBMISSIONS.put(key, JSON.stringify(payload));
  }

  // Redirect to thank-you page (303 to force GET)
  return Response.redirect('/thank-you', 303);
};
