#!/usr/bin/env node
/**
 * Cloudflare Pages _redirects guardrail.
 *
 * Fails if:
 * - Netlify-only syntax like "301!" exists
 * - Fully-qualified host redirects exist (http:// or https://) — not supported as domain-level redirects in Pages
 * - Any redirect rule sends extensionless -> .html with 301/302/307/308 (inverted for Pages default URL policy)
 *
 * Usage:
 *   node scripts/check-redirects-cloudflare.mjs [pathToRedirects]
 */
import fs from "node:fs";
import path from "node:path";

const file = process.argv[2] || "_redirects";
if (!fs.existsSync(file)) {
  console.error(`ERROR: _redirects not found at: ${file}`);
  process.exit(1);
}

const raw = fs.readFileSync(file, "utf8");
const lines = raw.split(/\r?\n/);

let hadError = false;

function fail(msg, lineNo, line) {
  hadError = true;
  console.error(`\n[FAIL] ${msg}`);
  if (lineNo != null) console.error(`  line ${lineNo + 1}: ${line}`);
}

lines.forEach((line, i) => {
  const trimmed = line.trim();
  if (!trimmed || trimmed.startsWith("#")) return;

  // Netlify-only bang syntax (301!)
  if (/\b\d{3}!\b/.test(trimmed)) {
    fail('Netlify-only redirect token found (example: "301!"). Cloudflare Pages expects numeric status codes.', i, line);
  }

  // Host-level redirects inside Pages _redirects are not supported as "domain-level redirects"
  // (and are operationally better enforced via Cloudflare Rules / Bulk Redirects).
  if (/^(https?:\/\/)/i.test(trimmed)) {
    fail("Host-level redirect detected in _redirects. Move host canonicalization to Cloudflare Rules → Bulk Redirects.", i, line);
  }

  // Parse: [source] [destination] [code?]
  const parts = trimmed.split(/\s+/);
  if (parts.length < 2) return;

  const source = parts[0];
  const dest = parts[1];
  const code = parts[2] ? Number(parts[2]) : 302;

  // Inverted policy: extensionless -> .html redirect (301/302/307/308) is wrong on Pages.
  // Use Pages default (.html -> extensionless) + clean canonicals, or proxying (200) if required.
  const isRedirect = [301, 302, 303, 307, 308].includes(code);
  if (isRedirect && !source.endsWith(".html") && dest.endsWith(".html")) {
    fail("Inverted redirect: extensionless → .html. Remove this rule (Pages already canonicalizes .html → extensionless).", i, line);
  }
});

if (hadError) {
  process.exit(2);
}
console.log("OK: _redirects passed Cloudflare guardrails.");
