# TopTier1 Update Pack (Hub Pages + Commercial Pages + Redirect/SEO Fixes)

This pack contains implementation-ready assets to add **Residential** + **Commercial** hub pages, add 2 commercial money pages + a consultation page, and fix foundational routing/SEO issues.

## Files included

### New pages (drop into repo root)

- `residential-electrician-allegan-mi.html`
- `commercial-electrician-allegan-mi.html`
- `commercial-led-lighting-retrofit.html`
- `commercial-electrical-maintenance.html`
- `electrical-design-consultation.html`

### SEO files

- `_redirects` (Cloudflare Pages)
- `sitemap.xml`
- `robots.txt`
- `thank-you.html` (noindex)

### Form backend (Cloudflare Pages Functions)

- `functions/api/form.js`

### Optional helpers

- `assets/js/utm.js` (populate hidden UTM fields + current page)
- `scripts/check-redirects-cloudflare.mjs` (CI guardrails)
- `.github/workflows/redirects-guard.yml` (example GitHub Action)

## How to integrate safely

1. **Copy head/header/footer from an existing production page**
   - The new HTML pages include a minimal head/header/footer.
   - For consistent design + analytics, copy the site-wide `<head>` assets and the shared header/footer markup from an existing page in your repo (example: `services.html`) into each new page.

2. **Ensure internal links are extensionless**
   - Links in this pack are already extensionless (`/services`, not `/services.html`).
   - Update the rest of the site to match to avoid redirect hops.

3. **Cloudflare Pages redirects**
   - Merge the `_redirects` entries into your existing `_redirects` file.
   - Keep host canonicalization out of `_redirects` and enforce it with **Cloudflare Rules → Bulk Redirects**.

4. **Fix the sitemap**
   - Add `sitemap.xml` to your build output so `https://toptier-electrical.com/sitemap.xml` returns 200.

5. **Forms**
   - Update your forms to `POST /api/form`.
   - Add Turnstile widget and hidden inputs:
     - `cf-turnstile-response` (Turnstile)
     - `utm_source`, `utm_medium`, `utm_campaign`, `utm_content`, `utm_term`, `gclid`, `page`
   - Bind `FORM_SUBMISSIONS` KV + `TURNSTILE_SECRET_KEY` env vars in Cloudflare Pages.

6. **(Optional) Add the guardrail script**
   - Run: `node scripts/check-redirects-cloudflare.mjs _redirects`

## Cloudflare Bulk Redirects (host canonicalization)

Create Bulk Redirect rules for:
- `toptier1.pages.dev/*` → `https://toptier-electrical.com/:splat` (301) with **Include subdomains** + preserve query string
- `www.toptier-electrical.com/*` → `https://toptier-electrical.com/:splat` (301) preserve query string
- (Recommended) force HTTP → HTTPS using Cloudflare "Always Use HTTPS" or a scheme-specific redirect.

## Generated

Date: 2026-02-08
